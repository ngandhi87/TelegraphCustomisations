(function(window)
	{
	var plugin = PluginInterface.registerNamespace('CombinePages','PDFE');
	plugin.panels = new Array();
	
	plugin.initialise = function()
		{
		var self = this;

		var modes = ['edition'];

		APP_API.createToolbar(plugin.fullname, "main", "CP", "Combine and Export Pages", self.resourceRoot  + "/images/icon_raw2.png", "buildCombinedPages", modes);
		plugin.registerEvent('buildCombinedPages', function() { plugin.buildCombinedPages(); });
		}

	plugin.buildCombinedPages = function()
		{
		var frontContainer = thePanelManager.getCurrentContainer();
		if (frontContainer != null)
			{
			var frontPanel = thePanelManager.getCurrentFocusPanel(frontContainer);
			if (frontPanel != null)
				{
				// get selection (of pages) and build a download file of the combined pages to download
				var hl_name = frontPanel.internalProperty('pageHitlistName');
				var hitlist_obj = findHitlistByName(hl_name);
				var selectionObj = hitlist_obj.getSelection();
				if (selectionObj)
					{
					var selected = selectionObj.getSelectionArray();
					
					var thisResourceRoot = this.resourceRoot;

					var downloadURL = thisResourceRoot + '/html/combine_pages.jsp?';
					

					if (selected.length < 2 || selected.length > 16)
						alert("Please re-select between two and sixteen pages. Do not select pages without a preview, they will NOT export but will count against the total.");
					else
						{
							
						var pubTitle = frontPanel.internalProperties["editionBrowser"].getTitle();
						var pubDate = frontPanel.internalProperties["editionBrowser"].getDate();
							
							
						for (var i in selected)
							{
							var a_sel = selected[i];
							if (i > 0)
								downloadURL += "&";
							downloadURL += "primaryKey=" + a_sel;
							}
						downloadURL += "&r=" + (new Date()).getTime();

						disablePanel(frontPanel, "Generating PDF");

						$.ajax({
							url : downloadURL,
							type : 'GET',
							dataType : 'text',
							success : function(data, status, xhr) 
								{
								var resp = JSON.parse(data);
								
								var export_status = resp.export_status;
								
								if (export_status == "ERROR")
									{
										var error_message = resp.error_message;
										enablePanel(frontPanel);
										alert(error_message);
									}
								else
									{
									var asset_id = resp.asset_id;

									// now fire off the download via servlet
									var downloadURL = appUrl + "/CHP/GetAsset?";
									//downloadURL += "primaryKey=" + resp[0] + "&type=a&dispositionType=attachment&internal=true";
									downloadURL += "primaryKey=" + asset_id + "&type=a&dispositionType=attachment&internal=true";
									downloadURL += "&r=" + (new Date()).getTime();
									//console.log(downloadURL);
									//window.open(downloadURL, "_blank");
		
									// this is used to generate a custom download filename
									var element = document.createElement('a');
									element.style.display = 'none';
									document.body.appendChild(element);

									var oReq = new XMLHttpRequest();
									oReq.open("GET", downloadURL, true);
									oReq.responseType = "blob";

									oReq.onload = function (oEvent) 
									  {

									  var file = new Blob([oReq.response], { type : 'application/octet-stream' });
									  element.href = window.URL.createObjectURL(file);
									  var filename = pubTitle + "_" + pubDate;
									  filename = filename.replace(/-/g, "_");
									  filename = filename.replace(/ /g, "_");
									  element.download = filename + ".pdf";
									  element.click();
									  document.body.removeChild(element);
									  
									  var deleteAttachURL = thisResourceRoot + '/html/delete_attachment.jsp?';
									  //deleteAttachURL += "primaryKey=" + resp[0];
									  deleteAttachURL += "primaryKey=" + asset_id;
									  deleteAttachURL += "&r=" + (new Date()).getTime();
									  //console.log(deleteAttachURL);

									  $.ajax({
										url : deleteAttachURL,
										type : 'GET',
										dataType : 'text',
										success : function(data, status, xhr)  
											{
											//console.log(data);
											}
										});
									  
									  enablePanel(frontPanel);

									  };
									oReq.send(null);
									}
								
								},
							error : function(xhr, status, error) {enablePanel(frontPanel);alert(error);}
							});
							
						}
					}
				else
					{
						alert("No page selected");
					}	
				}
			}
		}
	})(window);
