(function (window) {
    var plugin = PluginInterface.registerNamespace('CopyAssetID', 'CLIP');

    plugin.initialise = function () {
        var self = this;

        // Registering new functionality icon into a ribbon
        modes = ['assetdetails', 'assetpreview','assetproduction'];

        // modes = ['assetdetails:composite', 'assetdetails:picture', 'assetpreview:composite', 'assetpreview:picture', 'assetproduction:composite', 'assetproduction:picture'];
        //modes = ['assetdetails:composite', 'assetdetails:picture', 'assetpreview:composite', 'assetpreview:picture', 'assetproduction:composite', 'assetpreview:picture', 'hitlist:packages'];

        APP_API.createToolbar(this.fullname, "main", "CopyAssetID", "Copy Asset ID to Clipboard", 'spriteimage', "startCopyAssetID", modes);
        self.registerEvent('startCopyAssetID', function (event, panel) {
            self.startCopyAssetID(event);
        });
    };

    plugin.startCopyAssetID = function()
    		{
    		console.log("starting copy asset ID");
    		var frontContainer = thePanelManager.getCurrentContainer();
    		if (frontContainer != null)
    			{
    			var frontPanel = thePanelManager.getCurrentFocusPanel(frontContainer);
    			if (frontPanel != null)
    				{

                        var panelID = frontPanel.storedProperty('assetID');
                        if (panelID == null)
                        {
                            var fullKey = frontPanel.storedProperty('mostRecentSelectedPrimaryKey');

                            // This was changed in CHP 16.4.2, so use this option instead if its still null
                            if (fullKey == null)
                            {
                                fullKey = frontPanel.internalProperty('currentPreviewAsset');
                            }

                            if (fullKey != null) {
                                if (fullKey.indexOf(':') == -1)
                                    panelID = fullKey;
                                else
                                    panelID=fullKey.substring(0,fullKey.indexOf(':'));
                            }

                            // panelID = frontPanel.storedProperty('mostRecentSelectedPrimaryKey').substring(1, frontPanel.storedProperty('mostRecentSelectedPrimaryKey').indexOf(":"));
                            // Try this one as this shows the ID from the right click
                            //panelID = frontPanel.storedProperty('mostRecentSelectedPrimaryKey');

                        }

                        if (panelID != null) {
                            // APP_API.createPanel(this.fullname, 'Multisite info for ' + panelID, this.resourceRoot + '/html/multisite_info.jsp?asset_id=' + panelID, {'width' : 1000, 'height' : 600}, {type:'multisite_info', assetID:panelID});
                             var dummy = $('<input>').val(panelID).appendTo('body').select();
                             document.execCommand('copy');
                             APP_API.showNotification(this.fullname, "Copied to clipboard", "Asset ID " + panelID + " copied to clipboard");
                        }
                        else
                            alert("Failed to get an asset ID from front panel");
                    }

    			}
    		}
    })(window);
