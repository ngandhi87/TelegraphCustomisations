Summary of the SendToDTI plugin and related functionality:

- The plugin provides a user interface for sending assets to DTI. This adds a toolbar entry to results lists that displays a dialog asked for the desk name and batch name.
- The lists of desks is taken from an Integration system setting called "DTI_Desks" that is a JSON list of desks. There is no security on this (all users see all desks).
- Both desk and batch name are mandatory.
- The selected desk is saved/restored into a user preference called "DTI_Desk".
- The focus is initially set into the batch name field, and return in that field fires the "OK" action to create the batch.
- After the user fills in the details, a collection is created containing the set of assets. This has the DTICollection EMD added and filled in. A "Send to DTI" workflow job is then created, containing just the collection asset.
- The plugin also registers a keyboard shortcut for sending assets to DTI. This needs to be configured in user preferences to be available as a shortcut.
- A CHP workflow called "Send to DTI" defines the Start and Done states for workflow jobs used to wrap the request.
- The workflow state "Done" has a "run on change to" workflow script of "Send Workflow Job to DTI", which in turn calls a groovy script called SendWorkflowJobToDTI.
- The groovy script extracts the collection from the workflow job, then creates a "Send Collection to DTI" workflow action that sends an XML message to the DTI interface (configured in system.properties) to trigger the transfer activity. This uses the built-in CHP action called "SendDTICollectionRequestAction".
- DTI makes requests back to CMIS on HTTP port using MTOM, and connects as user DTIuser. This user needs to be updated to use a template so that they are considered a valid account.


TO INSTALL THIS CUSTOMISATION:
- Set the system.property in the CHP application to point at the DTI interface. (Requests are sent direct from the CHP application, not CHPSysMgt).
- Create a workflow in the CHP user interface called "Send To DTI" and add "Start" and "Done" states. This should be set to allow Compound assets in both states.
- Upload the plugin. This should also add the workflow scripts, groovy script, and system setting.
- Edit the workflow so that the Start state uses the "Send Workflow Job to DTI" script for the "Action on change to".
- Edit the icon_register system setting to add the toolbar icon: "DTI": "fas fa-share-square". This cannot be uploaded from the plugin otherwise it would override the other registered icons.
- Make sure that the DTIuser is using a profile template (instead of having explicit permissions associated with them).