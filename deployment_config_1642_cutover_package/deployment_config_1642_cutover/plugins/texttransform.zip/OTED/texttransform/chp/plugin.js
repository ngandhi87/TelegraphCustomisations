(function(window)
 	{
	var plugin = PluginInterface.registerNamespace("texttransform", "OTED");

	plugin.initialise = function initialise()
		{
		// this is how you specify that the plugin should appear in the context menu.
		plugin.contextmenu = true;
		plugin.toolbarPosition = 7;
		plugin.toolbarName = ['TransformTextSwitcher','TransformTextToLowercase','TransformTextToUppercase','TransformTextCapitalize'];
		}
	})(window);