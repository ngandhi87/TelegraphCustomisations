(function(window)
	{
	var plugin = PluginInterface.registerNamespace('SendToDTI','TELE');

	plugin.itsDesks = undefined;	

	plugin.initialise = function()
		{
		// cannot use subtype ':picture' as community folders doesn't set a subtype
		var modes = ['assetbrowser:picture','assetdetails:picture','assetpreview:picture','assetproduction:picture'];

		APP_API.createToolbar(plugin.fullname, "main", "DTI", "Send to DTI", "spriteimage", "send_to_dti", modes);
		plugin.registerEvent('send_to_dti', function() { plugin.sendToDTI(); });

		APP_API.registerKeyboardShortcut(plugin.fullname, "DTI", "Send to DTI", "panel", function(event) { plugin.sendToDTI(); } );

		// load desks from system settings
		var load_desks_url = plugin.resourceRoot + '/html/get_desks.jsp?_r=' + (new Date()).getTime();
		$.ajax({
	                    url : load_desks_url,
	                    type : 'GET',
	                    dataType : 'text',
	                    success : function(data, status, xhr)  
		                      {
				     plugin.itsDesks = JSON.parse(data);
				     console.log(plugin.itsDesks);
		                      }
	                    });
		}

	plugin.sendToDTI = function()
		{
		var self = this;
		var currentPanel = getCurrentGlobalFocusPanel();
		var hitlistName = ToolbarUtils.getCurrentHitlist(true);
		var hitlistObject = findHitlistByName(hitlistName);
		var pType = currentPanel.storedProperty("type");
		if (pType == 'hitlist' || pType == 'assetbrowser' || pType == 'assetdetails' || pType == 'assetpreview' || pType == 'assetproduction')
			{
			var selectedKeys = null;
			if (pType == 'hitlist' || pType == 'assetbrowser')
				{
				var hitlistSelection = hitlistObject.getSelection();
				selectedKeys = hitlistSelection.getSelectionArray(0, true);
				}
			else
				{
				var panelID = currentPanel.storedProperty('assetID');
				var selectedKeys = new Array();
				selectedKeys[0] = panelID;                           
				}

			if (selectedKeys != null)
				{
				var okToSend = true;
				if (selectedKeys.length > 10)
					{
					alert('You cannot send more than 10 pictures to DTI in one go. Please select less items and try again.');
					okToSend = false;
					}
				else
					{
					for (var i=0;i < selectedKeys.length; ++i)
						{
						if (selectedKeys[i].indexOf('PICT') == -1)
							okToSend = false;
						}
					if (!okToSend)
						alert('Some of the selected items are not pictures. Only pictures can be sent to DTI through this action.');
					}
					
					if (okToSend)
						{
						// display dialog to ask for send options
						var message = "";
						message += "<table>";

						message += "<tr>";
						message += "<td>DTI desk:</td>";
						message += "<td><select id=\"dti_desk\">";
						for (var i in plugin.itsDesks)
							message += "<option value=\"" + plugin.itsDesks[i] + "\">" + plugin.itsDesks[i] + "</option>";
						message += "</select></td>";
						message += "</tr>";

						message += "<tr>";
						message += "<td>Batch name:</td><td><input id=\"dti_batch_name\" type=\"text\"/></td>";
						message += "</tr>";
						message += "</table>";

						var buttons = [];
						var okbutton = {'title' : "OK", 'onclick' : function()
							{
							var desk_name = $('#dti_desk').val();
							var batch_name = $('#dti_batch_name').val();
							if (!batch_name || batch_name.trim() == '')
								{
								alert('You need to enter a batch name to be able to continue.');
								return false;
								}
							else
								{
								PreferenceUtils.preference("DTI_Desk", desk_name, true, null);

								var create_collection_url = self.resourceRoot + '/html/send_to_dti.jsp';
								create_collection_url += '?desk=' + encodeURIComponent(desk_name);
								create_collection_url += '&batch=' + encodeURIComponent(batch_name);
								for (var i=0;i < selectedKeys.length; ++i)
									create_collection_url += '&asset_id=' + encodeURIComponent(selectedKeys[i].substring(0,24));
								$.ajax({
							                    url : create_collection_url,
							                    type : 'GET',
							                    dataType : 'text',
							                    success : function(data, status, xhr)  
								                      {
								                      console.log(data);
								                      }
						                    });


								APP_API.showNotification('','Send to DTI',selectedKeys.length + ' pictures have been sent to DTI  desk ' + desk_name + ' as "' + batch_name + '".');
								return true;
								}
							}};
						buttons.push(okbutton);
						buttons.push({'title' :"Cancel"});
						
						// set up callback to set the focus into the batch name in the dialog and set keyboard handler for return key
						var callback = function(dialog)
							{
							var desk = $('#dti_desk');
							var batch_name = $('#dti_batch_name');

							var pref_desk = PreferenceUtils.preference("DTI_Desk");
							if (pref_desk)
								desk.val(pref_desk);

							batch_name.on('keypress', function(e) {
								if (e.keyCode == 13)
									{
									// simulate click on the OK button
									var okButton = $(".dialogbuttons > input[value='OK']", dialog);
									if (okButton) okButton.click();
									}
								});
							setTimeout(function() { batch_name.focus(); }, 200);
							};
						var optionsDialog = oAlert(message, {'title' : "Send selection to DTI", 'buttons' : buttons, 'callback': callback});
						}
				}
			}
		}
	})(window);